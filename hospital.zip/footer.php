<footer>
        <div class="container">
            <p>&copy; 2024 Hospital Guardian</p>
        </div>
    </footer>
</body>
</html>
