<?php include 'doctor_authorize.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Dashboard</title>
</head>
<body>
    <h1>Welcome, Doctor!</h1>
    <p>This is the doctor dashboard.</p>
    <a href="../logout.php">Logout</a>
</body>
</html>
