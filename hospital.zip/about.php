<?php include 'header.php'; ?>
<section class="about">
    <div class="container">
        <h2>About Hospital Management System</h2>
        <p>This is a placeholder text for the about page.</p>
    </div>
</section>
<?php include 'footer.php'; ?>
