<?php include 'header.php'; ?>
<section class="home">
    <div class="container">
        <h1>Welcome to Hospital Management System</h1>
        <p>This is a placeholder text for the homepage.</p>
    </div>
</section>
<?php include 'footer.php'; ?>
